function y=test(a)
y = a.^2;